from django.shortcuts import render, redirect

def index(request):
    return render(request, "disNinja/index.html")

# Create your views here.
